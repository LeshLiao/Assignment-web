import { createContext } from 'react';

export const LevelContext = createContext(1);
